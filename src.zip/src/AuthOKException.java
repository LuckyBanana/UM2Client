public class AuthOKException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2891659645234301894L;

}