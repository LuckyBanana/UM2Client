public class UM2Client {

	public static void main(String args[]) throws Exception{
		
		@SuppressWarnings("unused")
		ConnexionFrame connexion = new ConnexionFrame();
	}
}